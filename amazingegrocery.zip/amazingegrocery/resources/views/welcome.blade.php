<x-app-layout title="Welcome">
    <div class="py-5 d-flex justify-content-center align-items-center container flex-column gap-3">
        <div class="text-center">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <h1 class="text-muted">Find and Buy Your Grocery Here!</h1>
            <p class="text-muted">You Must Login First, If You Want To Go To Our Home Page</p>
            <a href="{{route('login.index')}}">Login Now!</a>
        </div>
    </div>
</x-app-layout>
