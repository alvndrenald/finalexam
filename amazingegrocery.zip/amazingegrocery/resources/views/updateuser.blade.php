<x-app-layout title="Update">
    <div class="card" style="margin:20px;">
        <div class="card-header">
            Update Role
        </div>
        <div class="card-body">
            <form action="/update/{{$users->id}}" method="POST">
                @csrf
                <label for="role" class="form-label fw-normal">Role</label>
                <select class="form-select" id="role" name="role">
                    <option selected>{{$users->role}}</option>
                    <option value="admin">
                        admin
                    </option>
                    <option value="user">
                        user
                    </option>
                </select>
                <br>
                <input type="submit" class="btn btn-warning">
            </form>
        </div>
    </div>
</x-app-layout>
