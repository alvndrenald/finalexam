<x-app-layout title="Info Logout">
    <div class="py-5 d-flex justify-content-center align-items-center container flex-column gap-3">
        <div class="text-center">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <h1 class="text-muted">See You Our Loyal Customer! ^_^</h1>
            <p class="text-muted">Do You Want To Go Back?<a href="{{route('login.index')}}"> Login Back!</a></p>
        </div>
    </div>
</x-app-layout>
