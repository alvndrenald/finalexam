<x-app-layout title="Info Purchase">
    <div class="py-5 d-flex justify-content-center align-items-center container flex-column gap-3">
        <div class="text-center">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <h1 class="text-muted">Thank You For Your Order!</h1>
            <p class="text-muted">We Will Contact You 1x24 hours.</p>
            <a href="{{route('home.index')}}">Click Here To "Home"</a>
        </div>
    </div>
</x-app-layout>
