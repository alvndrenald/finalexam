<x-app-layout title="Account Maintenance">
    {{-- <div class="py-3 d-flex justify-content-center align-items-center">
        <div style="width: 780px">
            <div class="d-flex justify-content-between">
                <form action="{{ route('manage.users') }}" method="GET">
                    <div class="input-group mb-3" style="width:330px;">
                        <input type="text" class="form-control" placeholder="Search Users" name="search">
                        <button class="btn btn-secondary" type="submit">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div>
                @forelse ($users as $user)
                    <div class="d-flex bg-white w-100 mb-3">
                        <div class="d-flex justify-content-between w-100 p-3">
                            <p class="fw-bolder fs-5">
                                {{ $user->name }}
                            </p>
                            <div class="d-flex align-items-start gap-2">
                                <a href="" type="button"
                                    class="btn btn-outline-warning">
                                    <i class="bi bi-pencil-fill"></i>
                                </a>
                                <form action="{{route('user.destroy', $user->id)}}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-outline-danger">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="alert alert-danger" role="alert">
                        User Not Found
                    </div>
                @endforelse
            </div>
            <div class="d-flex justify-content-end align-items-center mt-3">
                {{ $user->links() }}
            </div>
        </div>
    </div> --}}
    <div class="container">
        <div class="row" style="margin:20px">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="text-center">
                            <h4>Account Maintenance</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Role</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($users as $user)
                                        <tr>
                                            <td>{{$user->id}}</td>
                                            <td>{{$user->name}}</td>
                                            <td>{{$user->role}}</td>

                                            <td>
                                                <div class="d-flex">
                                                    <a href="{{url('/update/' . $user->id)}}" type="button" class="btn btn-outline-warning"><i class="bi bi-pencil-fill"></i></a>
                                                    <a href="{{url('/delete/' . $user->id)}}" type="button" class="btn btn-outline-danger"><i class="bi bi-trash-fill"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
