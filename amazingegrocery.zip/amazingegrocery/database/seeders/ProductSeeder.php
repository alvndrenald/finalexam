<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::create([
            'product_name' => 'Labu Acar Organik 500gr',
            'product_description' => 'Labu Acar atau Baby Labu Siam Tergolong dalam sayur yang banyak manfaatnya bagi  kesehatan.karena Baby labu ini memiliki kandungan
            Vitamin, serat, dan mineral menjadi satu paket yang komplit . Bahkan telah menjadi rahasia umum bahwa sayur ini bermanfaat dalam menurunkan tekanan darah bagi mereka yang memiliki riwayat hipertensi.',
            'product_price' => 15000,
            'product_image' => 'Labu Acar.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Tomat Lokal Organik',
            'product_description' => 'Berikut dibawah ini Kandungan yang ada didalam Buah Tomat :
            Air,Energi,Magnesium,Fosfor,Kalium,Sodium,Seng,Vitamin B1,Vitamin B2,Vitamin c
            Manfaat dari Buah Tomat : Meningkatkan kekebalan tubuh (imun), Anti oksidan, Menjaga usus dari bakteri yang dibawa oleh makanan, Bisa digunakan sebagai anti inflamasi.',
            'product_price' => 16000,
            'product_image' => 'Tomat.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Selada Romaine',
            'product_description' => 'Salah satu jenis selada yang  memiliki ciri-ciri daun berwarna hijau gelap yang kokoh dan tinggi dengan rusuk yang kuat di tengah cabang.
            Selada ini memiliki kadar gula dan natrium yang rendah, kadar protein, kalsium, vitamin K, zat besi , juga vitamin C yang tinggi. Selain itu selada ini juga memiliki kandungan tujuh belas kali vitamin A,',
            'product_price' => 12000,
            'product_image' => 'Selada.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Brokoli Organik',
            'product_description' => 'Brokoli (Brassica oleracea L. Kelompok Italica) adalah tanaman sayuran yang termasuk dalam suku kubis-kubisan atau Brassicaceae. Brokoli berasal dari daerah Laut Tengah dan sudah sejak masa Yunani Kuno dibudidayakan. Sayuran ini masuk ke Indonesia belum lama (sekitar 1970-an) dan kini cukup populer sebagai bahan pangan.',
            'product_price' => 17900,
            'product_image' => 'Brokoli.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Kacang Merah Kupas',
            'product_description' => 'Kacang merah sering digunakan sebagai bahan pembuatan makanan, seperti sup, rendang, maupun sebagai pelengkap pada hidangan penutup. Mengonsumsi kacang merah secara teratur mampu menurunkan risiko terjadinya beragam penyakit berbahaya, seperti penyakit jantung dan diabetes',
            'product_price' => 12000,
            'product_image' => 'Kacang Merah.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Lettuce Head',
            'product_description' => 'Sayur Lettuce Head Atau Iceberg merupakan Sayuran dari Keluarga Jenis Selada. Konsumsi Lettuce sangat sehat baik Untuk penyakit Spt Kanker ataupun untuk penunjang Program dieth. Sayur lettuce ( lettuce Head ) bisa di konsumsi dalam keadaan mentah setelah di cuci bersih. ataupun sebagai Bahan Sayur untuk Jenis makanan Salad ataupun Kebab Burger dll.',
            'product_price' => 9900,
            'product_image' => 'Lettuce Head.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Kale Curly',
            'product_description' => 'Daun kale mampu meningkatkan kontrol glukosa darah pada penderita diabetes, menurunkan risiko kanker, menurunkan tekanan darah, dan menurunkan risiko mengembangkan asma. Daun kale bisa cepat rusak atau busuk saat kena air. Maka dari itu, sangat disarankan untuk mencuci kale baru ketika akan dimasak saja. Jika sekiranya baru akan dimasak keesokan harinya atau besok lusa, bungkus daun kale dengan tisu lalu masukkan dalam plastik untuk kemudian disimpan dalam kulkas.',
            'product_price' => 15000,
            'product_image' => 'Kale Curly.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Oyong Organik',
            'product_description' => 'Sayur ini memiliki manfaat bagi kesehatan seperti menurunkan kadar gula darah. Oyong biasa diolah sebagai pendamping sayur bayam. Memiliki warna kulit hijau',
            'product_price' => 18600,
            'product_image' => 'Oyong.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Baby Buncis Organik',
            'product_description' => 'Baby buncis yang memiliki rasa manis ini juga bisa diolah bersama bahan lain.
            Kesegaran baby buncis bisa bertahan hingga seminggu bila dibungkus dengan kertas koran dan disimpan di lemari es bagian paling bawah.',
            'product_price' => 16000,
            'product_image' => 'Baby Buncis.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Cabe Merah Besar',
            'product_description' => 'Cabai merah besar dikenal juga dengan nama cabai teropong. Bentuknya panjang, besar, dan berwarna merah menyala. Meskipun besar, cabai ini tak terlalu pedas.',
            'product_price' => 13500,
            'product_image' => 'Cabe Merah.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Sawi Putih Organik',
            'product_description' => 'Sawi putih (Brassica rapa Kelompok Pekinensis; suku sawi-sawian atau Brassicaceae ) dikenal sebagai sayuran olahan dalam masakan Tionghoa; karena itu disebut juga sawi cina. Sebutan lainnya adalah petsai. Disebut sawi putih karena daunnya yang cenderung kuning pucat dan tangkai daunnya putih.',
            'product_price' => 14000,
            'product_image' => 'Sawi Putih.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Kentang Organik',
            'product_description' => 'Kentang adalah umbi yang sangat bergizi. Rendah lemak dan kalori, serta dapat menyediakan Anda hampir 50 persen dari total nilai vitamin C, B6, dan potasium harian yang direkomendasikan.',
            'product_price' => 17500,
            'product_image' => 'Kentang.jpg',
            'product_category_id' => 1
        ]);

        Product::create([
            'product_name' => 'Jagung Manis Organik',
            'product_description' => 'Jagung manis merupakan sayuran yang lembut dan lezat, dan dapat dikonsumsi dalam bentuk berbagai resep. Apa manfaat jagung bagi kesehatan? Kaya kalori, Dampak positif pada wasir dan kanker, Kaya vitamin, Kaya mineral, Antioksidan, Kesehatan jantung, Mencegah anemia, Mengurangi kolesterol LDL, Kaya vitamin A',
            'product_price' => 17500,
            'product_image' => 'Jagung Manis.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Kunyit',
            'product_description' => 'Kunyit mengandung senyawa aktif berwarna kuning yakni curcumin, yang biasa dijadikan pewarna makanan dan bumbu pada masakan. Kunyit banyak digunakan sebagai bahan baku jamu atau obat tradisional untuk berbagai penyakit',
            'product_price' => 12000,
            'product_image' => 'Kunyit.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Strawberry',
            'product_description' => 'Buah ini mengandung banyak pigmen warna Antosianin dan pastinya mengandung antioksidan tinggi.Buah strawberry mempunyai aroma dan rasa yang khas, jadi tidak heran jika buah ini digunakan sebagai perasa tambahan dalam makanan dan minuman.',
            'product_price' => 32000,
            'product_image' => 'Strawberry.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Ubi Ungu',
            'product_description' => 'Ubi ungu termasuk makanan yang memiliki sumber karbohidrat, kalium dan vitamin C yang tinggi. Ubi ini merupakan produksi Bionicfarm',
            'product_price' => 27000,
            'product_image' => 'Ubi Ungu.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Tauge',
            'product_description' => 'Tauge bisa dijadikan berbagai olahan makanan, mulai dari tumis, pecel, karedok, bahkan jadi pendamping soto dan rawon.',
            'product_price' => 13000,
            'product_image' => 'Tauge.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Bawang Putih',
            'product_description' => 'Fungsi bawang putih : Meningkatkan kekebalan tubuh, Menurunkan kolesterol jahat dan tekanan darah, Mencegah Alzheimer dan demensia',
            'product_price' => 25000,
            'product_image' => 'Bawang Putih.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Jahe',
            'product_description' => 'Jahe sering ditemukan sebagai kandungan jamu sebagai obat untuk menaikkan tingkat imunitas, seperti membantu mengatasi flu serta masuk angin',
            'product_price' => 20000,
            'product_image' => 'Jahe.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Selada',
            'product_description' => 'Jenis selada yang renyah dan enak ketika dikonsumsi mentah sebagai salad ataupun dijadikan tumis , sangat bermanfaat bagi tubuh karena memilki nutrisi yang sama dengan jenis sayuran hijau lainnya.',
            'product_price' => 10500,
            'product_image' => 'Selada.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Kol / Kubis',
            'product_description' => 'Sayuran dengan tekstur berlapis ini mengandung banyak vitamin
            Memiliki mineral yang dibutuhkan tubuh seperti kalsium, zat besi, yodium, kalium, belerang, fosfor dan folat
            Meningkatkan kesehatan jantung dan membantu dalam pengobatan peradangan dan kanker',
            'product_price' => 13500,
            'product_image' => 'Kol.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Seledri',
            'product_description' => 'Biasanya digunakan dalam soup untuk menambah selera makan. Dipercaya dapat sebagai obat peluruh air seni dan penurun tekan khusus yg berdarah rendah, disarankan tidak konsumsi terlalu banyak',
            'product_price' => 12950,
            'product_image' => 'Seledri.jpg',
            'product_category_id' => 2
        ]);

        Product::create([
            'product_name' => 'Kangkung',
            'product_description' => 'Kangkung (Ipomoea spp.) merupakan salah satu sayuran daun yang paling populer di Asia Tenggara. Kangkung dikenal juga dengan swamp cabbage, water convolvulus, dan water spinach.
            Manfaat kangkung : Menjaga kesehatan mata, mencegah diabetes, melawan penyakit hati (liver), dan lainnya.',
            'product_price' => 10000,
            'product_image' => 'Kangkung.jpg',
            'product_category_id' => 2
        ]);
    }
}
