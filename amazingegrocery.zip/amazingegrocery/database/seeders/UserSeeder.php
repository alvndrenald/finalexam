<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Chatarine Caroline',
            'email' => 'chatarinecaroline@gmail.com',
            'password' => bcrypt('chatarine19'),
            'gender' => 'Female',
            'date_of_birth' => '2002-12-19',
            'country_id' => 1,
            'photo' => 'chatarine.jpg'
        ]);

        User::create([
            'name' => 'Alvindra Renaldo',
            'email' => 'alvindrarenaldo@gmail.com',
            'password' => bcrypt('alvindra07'),
            'gender' => 'Male',
            'date_of_birth' => '2002-06-07',
            'country_id' => 3,
            'photo' => 'alvindra.jpg'
        ]);

        User::create([
            'name' => 'Dewi Bulan Irene',
            'email' => 'dewibulanirene@gmail.com',
            'password' => bcrypt('dewi07'),
            'gender' => 'Male',
            'date_of_birth' => '2004-06-07',
            'country_id' => 2,
            'photo' => 'dewibulanirene.jpg'
        ]);

        User::create([
            'name' => 'Dewi Bulan',
            'email' => 'dewi@admin.com',
            'password' => bcrypt('admin'),
            'gender' => 'Female',
            'role' => 'admin',
            'date_of_birth' => '2002-09-08',
            'country_id' => 5,
            'photo' => 'dewibulan.jpg'
        ]);

        User::create([
            'name' => 'Dewi Irene',
            'email' => 'dewiirene@gmail.com',
            'password' => bcrypt('dewi07'),
            'gender' => 'Female',
            'date_of_birth' => '2004-06-07',
            'country_id' => 1,
            'photo' => 'dewiirene.jpg'
        ]);

        User::create([
            'name' => 'Tricia Amadea',
            'email' => 'triciaamadea@admin.com',
            'password' => bcrypt('admin'),
            'gender' => 'Female',
            'role' => 'admin',
            'date_of_birth' => '2002-09-10',
            'country_id' => 3,
            'photo' => 'tricia.jpg'
        ]);

        User::create([
            'name' => 'Angeline Octavia',
            'email' => 'angelineoctavia@gmail.com',
            'password' => bcrypt('angeline07'),
            'gender' => 'Female',
            'date_of_birth' => '2002-06-07',
            'country_id' => 1,
            'photo' => 'angeline.jpg'
        ]);
    }
}
