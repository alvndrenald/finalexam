<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
  protected $fillable = ['name', 'country_id', 'email', 'password', 'gender', 'dob', 'photo'];

  public function __construct()
  {
    $this->middleware('auth');
  }

  public function __invoke()
  {
    $user = Auth::user();
    $user = $user->load('country');
    return view('profile', compact('user'));
  }

  public function accountMaintenance(){
    $users = User::all();
    return view('manageuser', compact('users'));
  }

  public function update($id){
    $users = User::find($id);
    return view('updateuser', compact('users'));
  }

  public function updateValue(Request $request, $id){
    $users = User::find($id);
    $input = $request->all();
    $users->update($input);
    return redirect()->route('manage.users')->with('success', 'Update User Successfully');
  }

  public function destroy($id){
    $users = User::find($id);
    $users->delete();
    return redirect()->route('manage.users')->with('success', 'Deleted User Successfully');
  }
}
